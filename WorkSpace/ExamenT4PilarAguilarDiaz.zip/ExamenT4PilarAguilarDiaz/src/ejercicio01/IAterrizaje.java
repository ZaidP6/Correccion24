package ejercicio01;

public interface IAterrizaje {

	public double calcularPrecioAterrizaje(double cantPorMetro, double cantPlusLitros, double cantPorPasajero, double cantPorPeligrosidad);
	
}
